Raymond Rees Jr
20161213

I wanted to challenge myself and make the value iteration without fully relying on the counter, so I took the mathematical formula Vk+1 = max(sum(Reward of transition + discount * val of transition)) and translated that the best I could into the init method, taking Q-value and pasting it into its respective function. I was running into the problem of having the counter trigger during initialization, so I had to make a copy of the counter before using its values in the init method.

I did not have time to implement the rest of the project, but will be finishing it outside of classtime. Life kinda got in the way, plus having tons of work during spring break already did not help. I spent 5 hours on Q1 alone, as I got stuck quite a bit.  